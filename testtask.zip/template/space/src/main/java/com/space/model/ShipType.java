package com.space.model;

public enum ShipType {
    TRANSPORT,
    MILITARY,
    MERCHANT
}